package com.example.demo.daos;

import com.example.demo.models.Region;
import java.sql.*;
import java.util.*;

public class RegionDao {
    private Connection conn;

    public RegionDao(Connection conn) {
        this.conn = conn;
    }

    public List<Region> getAllData() {
        List<Region> region = new ArrayList<>();
        String query = "Select regionId, regionName from region";
        try {
            ResultSet resultSet = conn.prepareStatement(query).executeQuery();
            while (resultSet.next()) {
                Region reg = new Region();
                reg.setRegionId(resultSet.getInt(1));
                reg.setRegionName(resultSet.getString(2));
                region.add(reg);
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
        return region;
    }

    public List<Region> getById() {
        List<Region> regions = new ArrayList<>();
        String query = "SELECT * FROM region WHERE regionId = ?";

        try {
            ResultSet resultSet = conn
                    .prepareStatement(query)
                    .executeQuery();
            while (resultSet.next()) {
                Region region = new Region();
                region.setRegionId(resultSet.getInt(1));
                region.setRegionName(resultSet.getString(2));
                regions.add(region);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return regions;
    }

    public boolean insertData(Region region) {
        try {
            PreparedStatement preparedStatement = conn
                    .prepareStatement("insert into region(regionId, regionName) values(?,?)");
            preparedStatement.setInt(1, region.getRegionId());
            preparedStatement.setString(2, region.getRegionName());
            int temp = preparedStatement.executeUpdate();
            return temp > 0;

        } catch (SQLException e) {
            // TODO: handle exception
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateData(Region region) {
        try {
            PreparedStatement preparedStatement = conn
                    .prepareStatement("update region set regionName = ? where regionId = ?");
            preparedStatement.setInt(2, region.getRegionId());
            preparedStatement.setString(1, region.getRegionName());
            int temp = preparedStatement.executeUpdate();
            return temp > 0;
        } catch (SQLException e) {
            // TODO: handle exception
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteData(Region region) {
        try {
            PreparedStatement preparedStatement = conn
                    .prepareStatement("delete from region where regionId = ?");
            preparedStatement.setInt(1, region.getRegionId());
            int temp = preparedStatement.executeUpdate();
            return temp > 0;
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
        return false;
    }

}
