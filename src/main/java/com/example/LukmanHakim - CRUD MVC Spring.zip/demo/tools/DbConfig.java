// package com.example.demo.tools;

// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;
// import org.springframework.jdbc.datasource.DriverManagerDataSource;

// @Configuration
// public class DbConfig {

// @Bean
// public DriverManagerDataSource getDataSource() {
// DriverManagerDataSource DbConfig = new DriverManagerDataSource();
// DbConfig.setDriverClassName("com.mysql.cj.jdbc.Driver");
// DbConfig.setUrl("jdbc:mysql://localhost:3306/belajar");
// DbConfig.setUsername("root");
// DbConfig.setPassword("AN@021nime20");
// return DbConfig;
// }
// }
