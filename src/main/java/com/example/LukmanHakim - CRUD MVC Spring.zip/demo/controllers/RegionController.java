package com.example.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.daos.RegionDao;
import com.example.demo.models.Region;
import com.example.demo.tools.DBConnection;

@Controller
@RequestMapping("region")
public class RegionController {
    RegionDao reg = new RegionDao(DBConnection.getConnection());

    @GetMapping
    public String index(Model model) {
        // Object region = reg.getAllData();
        model.addAttribute("regions", reg.getAllData());
        return "region/region-index";
    }

    // GET DATA
    @GetMapping("form")
    public String create(Model model) {
        model.addAttribute("region", new Region());
        return "region/form";
    }

    // Insert Data
    @PostMapping("save")
    public String save(Region region) {
        Boolean result = reg.insertData(region);
        if (result) {
            return "redirect:/region";
        } else {
            return "region/form";
        }
    }

    // Edit Data
    // get by id
    @GetMapping(value = "edit/{regionId}")
    public String edit(Model model) {
        model.addAttribute("region", new Region());
        return "region/edit";
    }

    @PostMapping("editsaved")
    public String editsaved(Region region) {
        Boolean result = reg.updateData(region);
        if (result) {
            return "redirect:/region";
        } else {
            return "region/edit";
        }
    }

    // DELETE
    @GetMapping(value = "/delete/{regionId}")
    public String delete(Region region) {
        Boolean result = reg.deleteData(region);
        if (result) {
            return "redirect:/region";
        } else {
            return "";
        }
    }
}
